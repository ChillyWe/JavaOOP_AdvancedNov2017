package cresla.entities.models.modules;

/**
 * Created by Chilly on 16.12.2017 г..
 */
public class HeatProcessor extends BaseAbsorbingModule {

    public HeatProcessor(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
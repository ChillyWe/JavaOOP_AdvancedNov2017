package cresla.entities.models.modules;

/**
 * Created by Chilly on 16.12.2017 г..
 */
public class CryogenRod extends BaseEnergyModule {

    public CryogenRod(int id, int energyOutput) {
        super(id, energyOutput);
    }
}

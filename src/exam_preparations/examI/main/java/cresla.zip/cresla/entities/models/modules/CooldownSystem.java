package cresla.entities.models.modules;

/**
 * Created by Chilly on 16.12.2017 г..
 */
public class CooldownSystem extends BaseAbsorbingModule {

    public CooldownSystem(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
package cresla.interfaces;

/**
 * Created by Chilly on 16.12.2017 г..
 */
public interface Runnable {
    void run();
}
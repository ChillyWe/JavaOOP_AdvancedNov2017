package app.utilities;

public class Constants {
    private Constants() {
    }
}

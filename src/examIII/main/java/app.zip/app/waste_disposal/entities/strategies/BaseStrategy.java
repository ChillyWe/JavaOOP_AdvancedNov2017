package app.waste_disposal.entities.strategies;

import app.waste_disposal.contracts.GarbageDisposalStrategy;

/**
 * Created by Chilly on 20.12.2017 г..
 */
public abstract class BaseStrategy implements GarbageDisposalStrategy{
}
package app.waste_disposal.entities.strategies;

import app.waste_disposal.contracts.ProcessingData;
import app.waste_disposal.contracts.Waste;

/**
 * Created by Chilly on 20.12.2017 г..
 */
public class RecyclableGarbageStrategy extends BaseStrategy {

    @Override
    public ProcessingData processGarbage(Waste garbage) {
        return null;
    }
}
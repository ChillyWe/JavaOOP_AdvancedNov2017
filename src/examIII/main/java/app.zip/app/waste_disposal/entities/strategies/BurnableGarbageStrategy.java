package app.waste_disposal.entities.strategies;

import app.waste_disposal.contracts.ProcessingData;
import app.waste_disposal.contracts.Waste;

/**
 * Created by Chilly on 20.12.2017 г..
 */
public class BurnableGarbageStrategy extends BaseStrategy {

    @Override
    public ProcessingData processGarbage(Waste garbage) {
  //      double energy = (garbage.getVolumePerKg() * garbage.getWeight()) * (1 - 0.2);

        return null;
    }
}